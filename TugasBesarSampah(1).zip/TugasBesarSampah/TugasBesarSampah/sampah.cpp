#include "sampah.h"

PilahSampah::PilahSampah() {
    akar = new NodeSampah();
    akar->kategoriUtama = "ROOT";
    akar->subKategori = "PEMISAH";
    akar->namaSampah = "UTAMA";
    akar->kiri = nullptr;
    akar->kanan = nullptr;
}

PilahSampah::~PilahSampah() {
    hapusTree(akar);
}

void PilahSampah::hapusTree(NodeSampah* node) {
    if (node == nullptr) return;
    hapusTree(node->kiri);
    hapusTree(node->kanan);
    delete node;
}

NodeSampah* PilahSampah::tambahRekursif(NodeSampah* node, string katUtama, string subKat, string nama) {
    if (node == nullptr) {
        NodeSampah* nodeBaru = new NodeSampah();
        nodeBaru->kategoriUtama = katUtama;
        nodeBaru->subKategori = subKat;
        nodeBaru->namaSampah = nama;
        nodeBaru->kiri = nullptr;
        nodeBaru->kanan = nullptr;
        return nodeBaru;
    }

    string kunciNode = node->subKategori + node->namaSampah;
    string kunciBaru = subKat + nama;

    if (kunciBaru < kunciNode) {
        node->kiri = tambahRekursif(node->kiri, katUtama, subKat, nama);
    } else {
        node->kanan = tambahRekursif(node->kanan, katUtama, subKat, nama);
    }

    return node;
}

void PilahSampah::tambah(string kategoriUtama, string subKategori, string namaSampah) {
    if (kategoriUtama == "Organik") {
        akar->kiri = tambahRekursif(akar->kiri, kategoriUtama, subKategori, namaSampah);
    } else if (kategoriUtama == "Anorganik") {
        akar->kanan = tambahRekursif(akar->kanan, kategoriUtama, subKategori, namaSampah);
    }
}

void PilahSampah::inOrderRekursif(NodeSampah* node) {
    if (node != nullptr) {
        inOrderRekursif(node->kiri);
        cout << "| " << node->kategoriUtama << " : "
             << node->subKategori << " : "
             << node->namaSampah << endl;
        inOrderRekursif(node->kanan);
    }
}

void PilahSampah::tampil() {
    cout << "\n=== [ SAMPAH ORGANIK ] ===" << endl;
    if (akar->kiri == nullptr) cout << "(Kosong)" << endl;
    else inOrderRekursif(akar->kiri);

    cout << "\n=== [ SAMPAH ANORGANIK ] ===" << endl;
    if (akar->kanan == nullptr) cout << "(Kosong)" << endl;
    else inOrderRekursif(akar->kanan);
    cout << "===============================\n";
}


void PilahSampah::cariRekursif(NodeSampah* node, string keyword, bool& ditemukan) {
    if (node == nullptr) return;

    if (node->namaSampah.find(keyword) != string::npos) {
        cout << ">> Ditemukan: " << node->namaSampah
             << " (" << node->kategoriUtama << " - " << node->subKategori << ")" << endl;
        ditemukan = true;
    }

    cariRekursif(node->kiri, keyword, ditemukan);
    cariRekursif(node->kanan, keyword, ditemukan);
}

void PilahSampah::cari(string keyword) {
    bool ditemukan = false;
    cout << "\n=== HASIL PENCARIAN: '" << keyword << "' ===" << endl;

    // Cari di cabang Organik (Kiri)
    cariRekursif(akar->kiri, keyword, ditemukan);

    // Cari di cabang Anorganik (Kanan)
    cariRekursif(akar->kanan, keyword, ditemukan);

    if (!ditemukan) {
        cout << "Maaf, data sampah '" << keyword << "' tidak ditemukan." << endl;
    }
    cout << "=====================================\n";
}
