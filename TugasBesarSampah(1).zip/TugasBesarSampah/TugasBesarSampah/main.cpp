#include <iostream>
#include "sampah.h"

using namespace std;

int main() {
    PilahSampah pohonSampah;
    int pilihan;
    string inputNama, katUtama, subKat;

    pohonSampah.tambah("Organik", "Makanan", "Nasi Sisa");
    pohonSampah.tambah("Anorganik", "Daur Ulang", "Botol Plastik");

    do {
        cout << "\nSISTEM PILAH SAMPAH";
        cout << "\n1. Tambah Data Sampah";
        cout << "\n2. Tampilkan Hasil Pilah";
        cout << "\n3. Cari Sampah";
        cout << "\n4. Keluar";
        cout << "\nPilihan: ";
        cin >> pilihan;
        cin.ignore();

        if (pilihan == 1) {
            int pilUtama, pilSub;

            cout << "\n[ Kategori Utama ]\n1. Organik\n2. Anorganik\nPilih (1/2): ";
            cin >> pilUtama; cin.ignore();

            if (pilUtama == 1) {
                katUtama = "Organik";
                cout << "\n[ Sub Kategori Organik ]";
                cout << "\n1. Sisa Makanan";
                cout << "\n2. Tanaman/Kebun";
                cout << "\nPilih Sub (1/2): ";
                cin >> pilSub; cin.ignore();

                if (pilSub == 1) subKat = "Makanan";
                else subKat = "Tanaman";

            } else {
                katUtama = "Anorganik";
                cout << "\n[ Sub Kategori Anorganik ]";
                cout << "\n1. Daur Ulang (Plastik/Kertas)";
                cout << "\n2. Residu/B3 (Baterai/Limbah)";
                cout << "\nPilih Sub (1/2): ";
                cin >> pilSub; cin.ignore();

                if (pilSub == 1) subKat = "Daur Ulang";
                else subKat = "Residu B3";
            }

            cout << "\nMasukkan Nama Item Sampah (misal: Kulit Pisang): ";
            getline(cin, inputNama);

            pohonSampah.tambah(katUtama, subKat, inputNama);
            cout << ">> Sukses! " << inputNama << " masuk ke kategori " << katUtama << " - " << subKat << endl;

        } else if (pilihan == 2) {
            pohonSampah.tampil();

        } else if (pilihan == 3) {
            string keyword;
            cout << "\nMasukkan kata kunci nama sampah: ";
            getline(cin, keyword);
            pohonSampah.cari(keyword);
        }

    } while (pilihan != 4);

    cout << "Program Selesai." << endl;
    return 0;
}
