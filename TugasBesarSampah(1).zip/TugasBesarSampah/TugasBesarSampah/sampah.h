#ifndef SAMPAH_H_INCLUDED
#define SAMPAH_H_INCLUDED

#include <string>
#include <iostream>

using namespace std;

struct NodeSampah {
    string kategoriUtama;
    string subKategori;
    string namaSampah;
    NodeSampah* kiri;
    NodeSampah* kanan;
};

class PilahSampah {
private:
    NodeSampah* akar;

    void cariRekursif(NodeSampah* node, string keyword, bool& ditemukan);

    NodeSampah* tambahRekursif(NodeSampah* node, string katUtama, string subKat, string nama);
    void inOrderRekursif(NodeSampah* node);
    void hapusTree(NodeSampah* node);

public:
    PilahSampah();
    ~PilahSampah();

    void tambah(string kategoriUtama, string subKategori, string namaSampah);
    void tampil();
    void cari(string keyword);
};

#endif // SAMPAH_H_INCLUDED
